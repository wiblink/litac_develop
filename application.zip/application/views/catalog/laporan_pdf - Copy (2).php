<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Specification Data</title>
	<!--<link href="<?php echo base_url();?>assets/utilpdf/bootstrap.min.css" rel="stylesheet"/>	
	<script type="text/javascript" src="<?php echo base_url();?>assets/utilpdf/bootstrap.bundle.min.js"></script>-->
    <style type="text/css">
      * {
        margin: 0;
        padding: 0;
        text-indent: 0;
      }

      .s1 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 6pt;
      }

      p {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        margin: 0pt;
      }

      .s2 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        vertical-align: 1pt;
      }

      .s3 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 11pt;
      }

      .s4 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .s5 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s6 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 5pt;
        vertical-align: 3pt;
      }

      .s7 {
        color: black;
        font-family: "Trebuchet MS", sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s8 {
        color: black;
        font-family: Symbol, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s9 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 4pt;
      }

      .s10 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 5pt;
        vertical-align: -1pt;
      }

      .s11 {
        color: black;
        font-family: "Trebuchet MS", sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .s12 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s13 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 4pt;
      }

      .s14 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 4pt;
      }

      h1 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .a,
      a {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 6pt;
      }

      table,
      tbody {
        vertical-align: top;
        overflow: visible;
      }
    </style>
  </head>
  <body>

    <table style="border-collapse:collapse;margin-left:10pt;margin-top:10pt; margin-right:10pt;" cellspacing="0" border="0">
      <tr style="height:10pt">
        <td colspan="3">
			<table width="100%" cellspacing="0" border="0">
				<!--<tr>
					<td class="s3" colspan="2" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">Share WA / Email</td>
				</tr>-->
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>        
      </tr>
	  <tr style="height:58pt">
        <td colspan="3">
			<table width="100%" cellspacing="0" border="0" >
				<tr>
					<td class="s2" style="padding-bottom: 2pt;padding-left: 2pt;text-indent: 0pt;line-height: 10pt;text-align: left;">
					
					<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;">PROJECT : <?php echo $dt->project; ?></p>
					<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;">AREA : <?php echo $dt->location; ?></p>
					<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;">STATUS : <?php echo $dt->status_project; ?></p>
					<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;">DATE : <?php echo date('d-m-Y',strtotime($dt->tanggal_project)); ?></p>
						<?php // echo base_url();?>
						</td>
					<td></td>
					<td></td>
					<td></td>
					<td class="s3" style="padding-bottom: 5pt;padding-top: 2pt;padding-left: 2pt;text-indent: 0pt;line-height: 10pt;text-align: center; border: 0.6px solid;">CODE<br><br><?php echo $dt->codelamp; ?></td>
				</tr>
			</table>
        </td>        
      </tr>
	  <tr style="height:58pt;">
        <td colspan="3" style="border-bottom: 0.6px solid;">
			<p class="s3" style="padding-bottom: 2pt;padding-left: 2pt;text-indent: 0pt;line-height: 10pt;text-align: left;"><br>Product data sheet</p>
        </td>        
      </tr>
	  <tr style="height:58pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          
          <p style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;" />
          <p class="s4" style="padding-top: 5pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Application</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;line-height: 92%;text-align: justify;">
		  <?php
		  $side = $dt->adv_lamp_side;
		  $lamp = $dt->lamp;
								if($side == 'I')
								{
									$lamp_catside =  'Indoor';
									$cat = $dt->adv_cat_indoor;
									if($cat!=null)
									{
										$category = json_decode(ecurl('GET','viewcatlamp/'.$cat))->data;
									$lamp_cat =  $category->name_product_type;
									} else {
										$lamp_cat =  '';
									}
									
								} else {
									$lamp_catside =  'Outdoor';
									$cat = $dt->adv_cat_indoor;
									if($cat!=null)
									{
									$category = json_decode(ecurl('GET','viewcatlamp/'.$cat))->data;
									$lamp_cat =  $category->name_product_type;
									} else {
										$lamp_cat =  '';
									}
								}
				echo 'Type '.$lamp_catside.' - '.$lamp_cat.'<br>'.$lamp;
		  ?>
		  </p>
        </td>
        <td style="width:173pt">
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Power (W)</b> : <?php echo $dt->power; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Voltage (V)</b> : <?php echo $dt->voltage; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Lumen (Lm)</b> : <?php echo $dt->lumen; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>CCT (Kelvin)</b> : <?php echo $dt->color_temperature; ?> <?php echo $dt->sw; ?></p>		
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>CRI</b> : <?php echo $dt->cri; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Optic</b> : <?php echo $dt->name_optic; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Beam Angle</b> : <?php echo $dt->beam_angle; ?> <?php echo $dt->beam_angleot; ?></p>
        </td>
        <td style="width:165pt">
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Diameter</b> : <?php echo $dt->dim_diameter; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Cut Out Diameter</b> : <?php echo $dt->dim_cut_o_diameter; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Height</b> : <?php echo $dt->dim_height; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Width</b> : <?php echo $dt->dim_width; ?></p>		
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Length</b> : <?php echo $dt->dim_length; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Weight</b> : <?php echo $dt->dim_weight; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Recessed Depth</b> : <?php echo $dt->dim_recc_depth; ?></p>
			<p class="s5" style="padding-left: 2pt;padding-right: 30pt;text-indent: 0pt;text-align: left;"><b>Housing Depth</b> : <?php echo $dt->dim_depth_housing; ?></p>
        </td>
      </tr>
      <tr style="height:244pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Control</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->name_control; ?></p>         
        </td>
        <td style="width:173pt" rowspan="16" colspan="2">
        
		<?php
		//https://www.daniweb.com/programming/web-development/threads/336438/displaying-thumbnails-in-a-5-column-table
		echo '<table width="100%">';
			$i = 0;
			$lampiran = json_decode(ecurl('GET','lampiran/'.$dt->lampiran))->data;
			foreach ($lampiran as $baris)
			{
			  if ($i % 2 == 0) 
				echo '<tr>';

			  echo "<td> <img src=lampiran/".$baris->nama_berkas." width='210'></td>";
			  if ($i % 2 == 4)
				echo '</tr>';

			  $i++;
			}

			if ($i % 2 > 0) 
			{
			  $i = 2 - ($i % 2);
			  echo "<td colspan='$i'>&nbsp;</td></tr>";
			}
			echo '</table>';
		?>
		
        </td>
        
      </tr>
	  <tr style="height:244pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Gears</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->gears; ?></p>
         
        </td>
        
      </tr>
	  <tr style="height:244pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Accesories</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->accesories; ?></p>         
        </td>       
      </tr>
	  <tr style="height:244pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Product</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->name_product_brand; ?> <?php echo $dt->code_product_brand; ?></p>         
        </td>
      </tr>
	  <tr style="height:244pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Product Shape</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;">
		  <?php echo $dt->shape; ?></p>         
        </td>
      </tr>
      <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Adjustable Optic</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;">
			<?php 
			$adj = $dt->adjustable; 
				if($adj == 'A')
				{
					$adjustable = 'Adjustable';
				} else if($adj == 'F')
				{
					$adjustable = 'Fixed';
				} else {
					$adjustable = '';
				}
				echo $adjustable;
			?>
          </p>          
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Tilt / Rotation (Deg)</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->tilt; ?> <?php echo $dt->rotation; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Reflector Material</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->tecspec_reflector; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Reflector Finish</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->name_ref_finish; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Body Material</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php 
			
			$body_material = $dt->body_material;
			
			echo $body_material; //($body_material != null ? $body_material : '-');
		   ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Product Colour</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->name_product_colour; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Cover Trim</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->tecspec_cover_trim; ?></p> 
        </td>
      </tr>	  
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">SDCM / MacAdam</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->sdcm; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">IP</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->tecspec_ip; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">UGR</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->ugr_rating; ?></p> 
        </td>
      </tr>
	  <tr style="height:71pt">
        <td style="width:175pt; border-bottom: 0.6px solid;">
          <p class="s4" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Instalation manual</p>
          <p class="s5" style="padding-left: 2pt;padding-right: 50pt;text-indent: 0pt;line-height: 92%;text-align: left;"><?php echo $dt->instalation_manual; ?></p> 
        </td>
      </tr>
      <tr style="height:166pt">
        <td style="width:175pt; border-bottom: 0.6px solid;" rowspan="2">
          
        </td>
        <td style="width:173pt" rowspan="2">
          
        </td>
        <td style="width:165pt">
         
        </td>
      </tr>
      <tr style="height:25pt">
        <td style="width:165pt" rowspan="2">
          
        </td>
      </tr>
      <tr style="height:24pt">
        <td style="width:175pt">
          <p style="text-indent: 0pt;text-align: left;">
            <br />
          </p>
        </td>
        <td style="width:173pt" rowspan="2">
         
        </td>
      </tr>
      <tr style="height:32pt">
        <td style="width:175pt">
          <p style="text-indent: 0pt;text-align: left;">
            <br />
          </p>
        </td>
        <td style="width:165pt">

        </td>
      </tr>
    </table>
    <p style="padding-top: 4pt;padding-left: 126pt;text-indent: 0pt;text-align: center;">
      <a href="mailto:litac@litac_consultant.com" class="a" target="_blank">LITAC Lighting & Acoustic Design Consultant Jakarta, Indonesia · info@</a><a href="http://litac-consultant.com/" class="a" target="_blank">litac-consultant.com</a> . 
      <a href="http://litac-consultant.com/" target="_blank">www.litac-consultant.com</a>
    </p>
  </body>
</html>