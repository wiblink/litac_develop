<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Specification Data</title>
	<!--<link href="<?php echo base_url();?>assets/utilpdf/bootstrap.min.css" rel="stylesheet"/>	
	<script type="text/javascript" src="<?php echo base_url();?>assets/utilpdf/bootstrap.bundle.min.js"></script>-->
    <style type="text/css">
      * {
        margin: 0;
        padding: 0;
        text-indent: 0;
      }

      .s1 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 6pt;
      }

      p {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        margin: 0pt;
      }

      .s2 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        vertical-align: 1pt;
      }

      .s3 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 11pt;
      }

      .s4 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .s5 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s6 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 5pt;
        vertical-align: 3pt;
      }

      .s7 {
        color: black;
        font-family: "Trebuchet MS", sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s8 {
        color: black;
        font-family: Symbol, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s9 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 4pt;
      }

      .s10 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 5pt;
        vertical-align: -1pt;
      }

      .s11 {
        color: black;
        font-family: "Trebuchet MS", sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .s12 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
      }

      .s13 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 4pt;
      }

      .s14 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 4pt;
      }

      h1 {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 8pt;
      }

      .a,
      a {
        color: black;
        font-family: Arial, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 6pt;
      }

      table,
      tbody {
        vertical-align: top;
        overflow: visible;
      }
    </style>
  </head>
  <body>

    <table style="border-collapse:collapse;margin-left:10pt;margin-top:10pt; margin-right:10pt;" cellspacing="0" border="0">
      <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td class="s7">PROJECT</td>
					<td class="s3" colspan="6" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">Adityawarman Residence</td>
				</tr>
				<tr>
					<td class="s7">AREA</td>
					<td class="s3" colspan="6" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">Interor lighting</td>
				</tr>
				<tr>
					<td class="s7">DATE</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
					<td class="s3" style="padding-left: 2pt;text-indent: 0pt;line-height: 1pt;text-align: left;">15 December 2022</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
	  <tr style="height:10pt">
        <td>
			<table width="100%" cellspacing="0" border="0">
				<tr>
					<td><img src='assets/img/logolitac.jpg' width='100'></td>
					<td class="s3" style="padding-bottom: 2pt;padding-left: 2pt;padding-top: 40pt;text-indent: 0pt;line-height: 1pt;text-align: right; ">OUTLINE SPECIFICATION&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</table>
			<br>
        </td>
      </tr>
    </table>
    <p style="padding-top: 4pt;padding-left: 126pt;text-indent: 0pt;text-align: center;">
      <a href="mailto:litac@litac_consultant.com" class="a" target="_blank">LITAC Lighting & Acoustic Design Consultant Jakarta, Indonesia · info@</a><a href="http://litac-consultant.com/" class="a" target="_blank">litac-consultant.com</a> . 
      <a href="http://litac-consultant.com/" target="_blank">www.litac-consultant.com</a>
    </p>
  </body>
</html>